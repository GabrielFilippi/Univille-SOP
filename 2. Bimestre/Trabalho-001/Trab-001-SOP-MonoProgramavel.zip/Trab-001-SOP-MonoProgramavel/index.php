<!doctype html>
<html lang='pt-br'>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Simulador MonoProgramavel.</title>
		<link rel="stylesheet" href="style/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="system/system.js"></script>
	</head>
	<body>
		<header>
			<div class="h2Header">
				<h2>Simulador de um Sistema Operacional MonoProgramavel. </h2>
			</div>
			<div class="navHeader">
				<nav id="menu">
					<ul>
						<li><a href="index.php">Solução</a></li>
						<li><a href="problema.php">Problema</a></li>
						<li><a href="https://github.com/GabrielFilippi/Univille-SOP/tree/master/2-Bimestre/Trabalho-001" target="_blank">GitHub</a></li>
					</ul>
				</nav>
			</div>
		</header>
		<div id="content">
			<div class="content-box center" style="text-align: center">
				<h3>Iniciar Processamento</h3>
				<p>Selecione abaixo um arquivo que será lido!</p>
				<select name="selArquivos" id="selArquivos">
					<option value="">Selecione...</option>
					<option value="Arquivo1.txt">Arquivo1.txt</option>
					<option value="Arquivo2.txt">Arquivo2.txt</option>
					<option value="Arquivo3.txt">Arquivo3.txt</option>
				</select>
				<button type="button" class='btn btn-proccess' onClick="runProccess()" style='margin-top: 25px'>Iniciar Simulador!</button>
			</div>
			<div class="content-box center">
				<h3>Simulador SO Monotarefa</h3>
				<table style="margin:5px">
					<thead>
						<tr>
							<th>Executanto o processo</th>
							<th>Tipo do processo</th>
							<th>Tempo estimado de execução</th>
							<th>Tempo restante</th>
						</tr>
					</thead>
					<tbody id="tbodyMonotarefa">
						<tr class="trMonotarefa item_X hidden">
							<td class='processo'></td>
							<td class='tipoProcesso'></td>
							<td class='tempoEstimado'></td>
							<td class='tempoRestante'></td>
						</tr>
					</tbody>
				</table>
				<div id="Relatorio" hidden>
					<hr>
					<p id='console' style="text-align: center;"><b>RELATÓRIO</b></p>
					<p>Tempo total de execução: <span><b id="totalExecucao"></b></span> </p>
					<p>Tempo total de execução processos CPU: <span><b id="totalExeCpu"></b></span></p>
					<p>Tempo total de execução processos ES: <span><b id="totalExeEs"></b></span></p>
					<p>Tempo de espera médio dos processos: <span><b id="mediaProcessos"></b></span></p>
					<br>
					<p id="Download" hidden>Deseja Fazer o Dowload do relatorio? <a href="download-output/saida.txt" download="Relatório(saida.txt).txt">Download Aqui.</a></p>
				</div>
			</div>
		</div>
	</body>
	<footer>
		<p>@<?php echo date("Y")?>. Todos os direitos reservados aos desenvolvedores do projeto.</p>
		<p><b>Desenvolvedores:</b> Gabriel Filippi e Maria Eduarda Pereira.</p>
	</footer>
</html>