<!doctype html>
<html lang='pt-br'>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Simulador MonoProgramavel.</title>
		<link rel="stylesheet" href="style/style.css">
	</head>
	<body>
		<header>
			<div class="h2Header">
				<h2>Simulador de um Sistema Operacional MonoProgramavel. </h2>
			</div>
			<div class="navHeader">
				<nav id="menu">
					<ul>
						<li><a href="index.php">Solução</a></li>
						<li><a href="problema.php">Problema</a></li>
						<li><a href="https://github.com/GabrielFilippi/Univille-SOP/tree/master/2-Bimestre/Trabalho-001" target="_blank">GitHub</a></li>
					</ul>
				</nav>
			</div>
		</header>
		<div id="content">
			<div class="content-box center">
				<h3>Desenvolva um programa que simule um sistema operacional monoprogramável.</h3>
				<p>
					O programa deverá ler um arquivo de entrada contendo a lista de processos que deverá ser executada.
					<br>
					No arquivo conterá as informações de cada processo (nome, tipo e duração).
					<br>
					Exemplo do arquivo de entrada.txt: <br>
					<br>
					#nome #tipo #duracao
					<br>
					p1  cpu  2 <br>
					p1  es 4 <br>
					p1 cpu 4 <br>
					p2 cpu 2 <br> <br>
					Cada unidade da duração do processamento do processo corresponderá a um ciclo do processador. E cada ciclo do processador deverá durar exatamente 1 segundo. <br>
					O simulador deverá indicar qual o processo está executando, quanto tempo resta e qual é o seu tipo. <br> <br>
				</p>
				<p>
					<b>Exemplo da tela do simulador:</b> <br> <br>
					Simulador SO Monotarefa <br>
					Executanto o processo: p1 <br>
					Tipo do processo: CPU <br>
					Tempo estimado de execução: 8 <br>
					Tempo restante: 8 <br>
				</p>
				<p>
					Ao final da execução o simulador deverá gerar um arquivo com o relatório da execução com as seguintes informações: <br> <br>
					<b>Exemplo do arquivo de saida.txt:</b> <br>
					Tempo total de execução: XXX <br>
					Tempo total de execução processos CPU: XXX <br>
					Tempo total de execução processos ES: XXX <br>
					Tempo de espera médio dos processos: XXX <br> <br>
				</p>
				<p>
					<b>Regras:</b> <br>

					*É obrigatório a leitura e escrita de arquivos <br>
					*Permitido utilizar qualquer linguagem de programação. <br>
					*Interface gráfica receberá pontos extras. <br>
					*Geração do gráfico de gantt receberá pontos extras. <br>
				</p>
			</div>
		</div>
	</body>
	<footer style="position: inherit">
		<p>@<?php echo date("Y")?>. Todos os direitos reservados aos desenvolvedores do projeto.</p>
		<p><b>Desenvolvedores:</b> Gabriel Filippi e Maria Eduarda Pereira.</p>
	</footer>
</html>