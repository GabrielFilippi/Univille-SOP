<?php
if($_POST['output']){
	//exlui caso ja existir 
	unlink("../download-output/saida.txt");
	$output = $_POST['output'];
	// Abre ou cria o arquivo bloco1.txt
	// "a" representa que o arquivo é aberto para ser escrito
	$fp = fopen("../download-output/saida.txt", "a");
	for($i=0;$i<count($output);$i++){
		fwrite($fp, $output[$i]."\n");
	}
	// Fecha o arquivo
	fclose($fp);
	return;
}
?>