//criamos a função sleep
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}
//função onde buscamos o os dados de dentro do arquivo.
function lerArquivo(handleData) {
	var arquivo = $("#selArquivos").val();
	$.ajax({
		type: "POST",
		url: 'system/system.php',
		data: {arquivo:arquivo}, 
		success:function(data) {
			data = jQuery.parseJSON(data);
			handleData(data); 
		}
	});
}
//função principal
function runProccess() {
	alert("Simulador ativado!");
	var arquivo = $("#selArquivos").val();
	if(arquivo){
		$("#Relatorio").hide();
		$("#Download").hide();
		//pego a tr completa da tabela e a mesma servira de copia.
		var copiaTBody = $("#tbodyMonotarefa").html();
		//chamando a função ler arquivo e recebendo o output dela que neste caso é os dados lidos do arquivo.
		//para conseguirmos fazer com que o for rode apenas a cada 1seg temos que usar o async na função.
		lerArquivo(async function(data){
			if(data.msgStatus==0){
				//conta a quantidade de objetos
				var getLength = function(obj) {
					var i = 0, key;
					for (key in obj) {
						if (obj.hasOwnProperty(key)){
							i++;
						}
					}
					return i;
				};
				var qtdArray = getLength(data.processamento);

				var totalExecucao =0;
				var totalExeCpu =0;
				var totalExeEs =0;
				var mediaProcessos =0;
				for(var i=0; i<qtdArray;i++){
					// se nao for igual a zero ou seja, ja tem ao menos uma linha na tabela, ele vai copiar o corpo da tabela ja existente e juntar com o tr que iremos modificar.
					if(i!==0){
						var TbodyAtual = $("#tbodyMonotarefa").html();
						$("#tbodyMonotarefa").html(TbodyAtual+copiaTBody)	
					}
					//modificamos o tr
					$(".item_X").addClass("item_"+i);
					$(".item_"+i).removeClass("item_X");
					$(".item_"+i).removeClass("hidden");
					//adicionamos os dados na tabela
					var nome = data.processamento[i].nome;
					var tipo = data.processamento[i].tipo;
					var tempoRestante = data.processamento[i].tempo;
					$(".item_"+i+" > .processo").html(nome);
					$(".item_"+i+" > .tipoProcesso").html(tipo);
					$(".item_"+i+" > .tempoEstimado").html(tempoRestante);
					//decrementamos o tempo restante seguindo o padrão de 1 segundo a cada decremento.
					for(var x=tempoRestante; x>=0;x--){
						$(".item_"+i+" > .tempoRestante").html(x);
						await sleep(1000); // chamamos a função sleep onde só pode iniciar o novo loop quando a promissa for completada.
					}
					// faz os calculos para o relatorio
					var tempo = parseInt(tempoRestante);
					totalExecucao+= tempo;
					if(tipo=='cpu'){
						totalExeCpu+=tempo;
					}else if(tipo=='es'){
						totalExeEs+=tempo;
					}
				}
				//mostra os valores calculados acima e mostra na tela
				$("#totalExecucao").html(totalExecucao);
				$("#totalExeCpu").html(totalExeCpu);
				$("#totalExeEs").html(totalExeEs);
				$("#mediaProcessos").html(totalExecucao/qtdArray);
				//mostra div de relatorio
				$("#Relatorio").show();

				var arrayValores = new Array();
				arrayValores[0]="Tempo total de execução: "+totalExecucao;
				arrayValores[1]="Tempo total de execução processos CPU: "+totalExeCpu;
				arrayValores[2]="Tempo total de execução processos ES: "+totalExeEs;
				arrayValores[3]="Tempo de espera médio dos processos: "+totalExecucao/qtdArray;
				//enviamos os valores calculados para o php e criamos um arquivo saida.txt
				$.ajax({
					type: "POST",
					url: 'system/gerarRelatorio.php',
					data: {output:arrayValores}, 
					success:function(data) {
						$("#Download").show();

					}
				});	
			}else{
				alert(data.msg);
			}

		});
	}else{
		alert("Selecione um arquivo para ser lido!")
	}
}