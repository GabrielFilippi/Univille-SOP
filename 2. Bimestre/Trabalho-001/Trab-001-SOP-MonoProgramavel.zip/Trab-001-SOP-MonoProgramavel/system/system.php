<?php
/*
$return=array(
	'processamento'=> array(
		'nome' => #nome do processamento
		'tipo' => #tipo do processamento
		'tempo' => #tempo de execucao
	)
	'msgStatus'=> #aqui podemos ter 0 ou 1, onde zero reprenta que não houve nenhum erro e 1 que teve algum erro.
	'msg'=> #aqui escrevemos a msg de erro
);
*/
$arquivo = $_POST['arquivo'];
$return=array();
//verifica se o arquivo existe
if(file_exists("arquivos/".$arquivo)){
    $file_handle = fopen("arquivos/".$arquivo, "r");
	$i=0;
	while (!feof($file_handle)) {
		$line = fgets($file_handle); #pega a linha em questao do arquivo
		$dadosExplode = explode(' ', $line); //vai separar os dados quando tiver um espaço entre eles, ficara em um array.
		$return['processamento'][$i] = array(
			'nome'=>$dadosExplode[0],
			'tipo'=>$dadosExplode[1],
			'tempo'=>$dadosExplode[2],

		);
		$i++;
	}
	$return['msgStatus']=0;
	fclose($file_handle); #fecha o arquivo que foi aberto
}else{
	$return['msgStatus']=1;
	$return['msg']="Não é possivel acessar o arquivo ".$arquivo." ou o mesmo não existe.";
}
echo json_encode($return, JSON_FORCE_OBJECT);	
?>